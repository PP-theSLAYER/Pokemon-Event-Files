Generation IV 
Pokemon Diamond, Pearl, Platinum, HeartGold, SoulSilver Versions
Event Pokemon Collection
from projectpokemon.org

Full Event Gallery:
http://projectpokemon.org/events

This collection is constantly updated.
For the latest version and information, see:
http://projectpokemon.org/forums/showthread.php?15283-Gen-IV-Event-Collection-and-Contribution-Thread

We don't restrict the usage of these files, but if you host them somewhere else, we ask you to credit the site where it was obtained (here, projectpokemon.org).  We ask this partially as a courtesy to those who contributed, those worked to compile and organize this collection, and due to the fact that the collection is coninuously being updated.